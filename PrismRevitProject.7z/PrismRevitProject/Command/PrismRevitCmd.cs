﻿using Autodesk.Revit.Attributes;
using Autodesk.Revit.DB;
using Autodesk.Revit.UI;
using PrismRevitProject.Prism;
using PrismRevitProject.ViewModels;
using PrismRevitProject.Views;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace PrismRevitProject.Command
{
    [Transaction(TransactionMode.Manual)]
    public class PrismRevitCmd : IExternalCommand
    {

        public Result Execute(ExternalCommandData commandData, ref string message, ElementSet elements)
        {
            //PrismUnit.CreateWindow<MainWindow>().Show();
            MainViewModel mainViewModel = new MainViewModel();
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();




            return Result.Succeeded;
        }
    }
}
