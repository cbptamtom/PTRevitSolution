﻿using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace PrismRevitProject.ViewModels
{
    public class GeometryViewModel : BindableBase
    {
        public ICommand GeometryCommand { get; private set; }

        public GeometryViewModel()
        {
            GeometryCommand = new DelegateCommand(() => MessageBox.Show("Geometry"));
        }
    }
}
