﻿using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace PrismRevitProject.ViewModels
{
    public class SettingViewModel : BindableBase
    {

        public ICommand SettingCommand { get; private set; }
        public SettingViewModel()
        {
            SettingCommand = new DelegateCommand(() => MessageBox.Show("Setting"));
        }
    }
}
