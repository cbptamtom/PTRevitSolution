﻿using Prism.Commands;
using Prism.Mvvm;
using PrismRevitProject.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace PrismRevitProject.ViewModels
{
    public class MainViewModel : BindableBase
    {



        public ObservableCollection<MenuItemViewModel> MenuItems { get; }
        private UserControl currentView;
        public UserControl CurrentView
        {
            get { return currentView; }
            set { SetProperty(ref currentView, value); }
        }

        private SettingViewModel _settingViewModel;
        public SettingViewModel SettingViewModel
        {
            get { return _settingViewModel; }
            set { SetProperty(ref _settingViewModel, value); }
        }

        private GeometryViewModel _geometryViewModel;
        public GeometryViewModel GeometryViewModel
        {
            get { return _geometryViewModel; }
            set { SetProperty(ref _geometryViewModel, value); }
        }



        public ICommand TestCommand { get; private set; }
        public ICommand ShowSettingViewCommand { get; set; }
        public ICommand ShowGeometryViewCommand { get; set; }

        public MainViewModel()
        {

            _settingViewModel = new SettingViewModel();
            _geometryViewModel = new GeometryViewModel();
            CurrentView = new SettingView();
            TestCommand = new DelegateCommand(() => MessageBox.Show("Test"));


            ShowSettingViewCommand = new DelegateCommand(ShowSettingView);
            ShowGeometryViewCommand = new DelegateCommand(ShowGeometryView);
        }



        private void ShowSettingView()
        {
            CurrentView = new SettingView();
        }

        private void ShowGeometryView()
        {
            CurrentView = new GeometryView();

        }
    }
}
