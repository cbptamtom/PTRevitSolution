﻿using Autodesk.Revit.UI;
using DryIoc;
using Prism.DryIoc;
using Prism.Ioc;
using Prism.Modularity;
using Prism.Mvvm;
using Prism.Regions;
using System.Windows.Controls.Primitives;
using System.Windows.Controls;
using System;

namespace PrismRevitProject.Prism
{
    public abstract class PrismExternalApplication : IExternalApplication
    {
        internal static PrismExternalApplication Instance { get; private set; }

        private readonly IContainerExtension _containerExtension = CreateContainerExtension();
        private readonly IModuleCatalog _moduleCatalog = new ModuleCatalog();

        public IContainerProvider Container => _containerExtension;

        public PrismExternalApplication()
        {

            Instance = this;
        }

        /// <inheritdoc />
        public virtual Result OnStartup(UIControlledApplication application)
        {
            try
            {
                // Đặt hàm Factory mặc định để lấy ViewModel tương ứng với View
                ViewModelLocationProvider.SetDefaultViewModelFactory((view, type) => Container.Resolve(type));

                _containerExtension.RegisterInstance(_containerExtension);
                _containerExtension.RegisterInstance(_moduleCatalog);

                // Đăng ký các loại dịch vụ và đối tượng cần thiết tại đây

                _containerExtension.FinalizeExtension();

                ConfigureModuleCatalog(_moduleCatalog);

                RegionAdapterMappings regionAdapterMappings = Container.Resolve<RegionAdapterMappings>();
                if (regionAdapterMappings != null)
                {
                    regionAdapterMappings.RegisterMapping(typeof(Selector), Container.Resolve<SelectorRegionAdapter>());
                    regionAdapterMappings.RegisterMapping(typeof(ItemsControl), Container.Resolve<ItemsControlRegionAdapter>());
                    regionAdapterMappings.RegisterMapping(typeof(ContentControl), Container.Resolve<ContentControlRegionAdapter>());
                }

                Container.Resolve<IModuleManager>()?.Run();

                return Result.Succeeded;
            }
            catch (Exception ex)
            {
                // Xử lý lỗi ở đây hoặc ghi log để theo dõi lỗi
                Console.WriteLine("Lỗi trong OnStartup: " + ex.Message);
                return Result.Failed;
            }
        }


        /// <inheritdoc />
        public virtual Result OnShutdown(UIControlledApplication application)
        {
            return Result.Succeeded;
        }

        /// <summary>
        /// Đăng ký các loại dịch vụ và đối tượng cần thiết tại đây
        /// </summary>
        protected abstract void RegisterTypes(IContainerRegistry containerRegistry);

        /// <summary>
        /// Cấu hình Module Catalog của Prism (nếu có)
        /// </summary>
        protected virtual void ConfigureModuleCatalog(IModuleCatalog moduleCatalog) { }

        private static IContainerExtension CreateContainerExtension()
        {
            Rules rules = Rules.Default.WithAutoConcreteTypeResolution()
                .WithDefaultIfAlreadyRegistered(IfAlreadyRegistered.Replace)
                .With(Made.Of(FactoryMethod.ConstructorWithResolvableArguments));

            var container = new Container(rules);
            return new DryIocContainerExtension(container);
        }
    }
}
