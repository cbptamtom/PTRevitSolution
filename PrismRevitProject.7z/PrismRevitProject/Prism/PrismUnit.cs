﻿using System;
using System.Windows;
using Prism.Ioc;
using Prism.Regions;

namespace PrismRevitProject.Prism
{
    public static class PrismUnit
    {
        public static IContainerProvider GetContainer()
        {
            if (PrismExternalApplication.Instance != null)
            {
                return PrismExternalApplication.Instance.Container;
            }
            else
            {
                // Xử lý lỗi hoặc trả về một giá trị mặc định
                Console.WriteLine("Lỗi: PrismExternalApplication.Instance là null.");
                return null; // hoặc trả về giá trị mặc định khác
            }
        }

        public static T CreateWindow<T>() where T : Window
        {
            T window = Activator.CreateInstance<T>();
            RegionManager.SetRegionManager(window, GetContainer().Resolve<IRegionManager>());
            RegionManager.UpdateRegions();
            return window;
        }
    }
}
